$("#add-user").submit(function(event){
    alert("Data inserted succesfully");
})