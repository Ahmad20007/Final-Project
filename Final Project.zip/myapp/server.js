const express=require('express');
const dotenv=require('dotenv');
const morgan=require('morgan');
const bodyparser=require('body-parser');
const BlogDB=require('./model/model');

const app=express();

dotenv.config({path:'config.env'})

//log requests
app.use(morgan('tiny'));

//parse request
app.use(bodyparser.urlencoded({extended:true}))
//set iew engine
app.set("view engine","ejs")

const connectDB=require("./database/connection");
connectDB();

app.use(express.urlencoded({extended:false}));


app.get("/home",(req,res)=>{
    if(req.query.category){
        let cat={};
            cat={category:req.query.category.split(',')};
           BlogDB.find(cat).then(blog=>{
            if(!blog){       
                res.send("error occured")
                      }
                      else{  
                      res.render("category",{blog});
                  }}).catch(err=>{
                    res.send("error occured")
                  })
                }
    else{
    BlogDB.find().then(blog=>{
        res.render("home",{blog})
    })
    .catch(err=>{
        res.send("error occured")
})}})

app.get("/blogs",(req,res)=>{
    BlogDB.find().then(blog=>{
        res.render("blogs",{blog})
    })
    .catch(err=>{
        res.send("error occured")
})
})

//create 
app.get("/create",(req,res)=>{
    res.render("create");
})

app.post("/home",(req,res)=>{
    if(!req.body){
        res.send("error occureddd")
    }
    else{
        const users= new BlogDB({
            author:req.body.author,
            title:req.body.title,
            description:req.body.description,
            image:req.body.image,
            date:req.body.date,
            category:req.body.category
        })
        users.save(users).then(users=>{
if(!users){
    res.send("errrror occured")
}
else{
            res.redirect("/home");}
         })
        .catch(()=>{
            res.send("error occured")
        })
    }
})

app.get("/home/:id",(req,res)=>{
    console.log(req.params.id);
     if(req.params.id){
        const id = req.params.id;
        BlogDB.findById(id).then(blog=>{
            if(!blog){
                res.send("error occured")
            }
            else{
                res.render("show",{blog})
            }
        }).catch(err=>{
            res.send("error occured")
        })
    }
    else{
        res.send("error occured")
    }
})

app.get("/update-user",(req,res)=>{
    if(req.query.id){
    const id= req.query.id;
    BlogDB.findById(id).then(update=>{
        if(!update){
            res.send("error occured123")
        }
        else{
            res.render("update",{update})
    }   
}).catch(err=>{
    res.send("error occured")
})
}else{
    res.send("error occured")

}})

app.post("/update/:id",(req,res)=>{
   if(!req.body.date){
    res.send("error occured")
   }
   else if(!req.params.id){
    res.send("error occured")
   }
   else{
    const users = req.params.id;
    BlogDB.findByIdAndUpdate(users,req.body,{useFindAndModify:false}).then(blog=>{
        if(!req.body){
            res.send("error occured")
        }
       res.redirect("/home");
    }).catch(err=>{
        res.send("error occured")
    })
   }
})



app.get("/delete/:id",(req,res)=>{
    const id = req.params.id;
    BlogDB.findByIdAndDelete(id).then(user=>{
        if(!user){
           res.render("errors/error2")
        }
        else{
            res.redirect("/home");
        }    
    }).catch(err=>{
        res.render("errors/error2")
    })
})

app.listen(3000,()=>{
  console.log('Server is running on http://localhost:3000')
})
